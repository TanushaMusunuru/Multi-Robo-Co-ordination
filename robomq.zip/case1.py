import numpy as np
import matplotlib.pyplot as plt
import random
from collections import deque
import time

# Set a random seed for reproducibility
random.seed(42)

# Warehouse grid setup
grid_size = (10, 10)
grid = np.zeros(grid_size)

# Robot configurations
robots = [
    {"pos": [0, 0], "goal": [9, 0], "color": "blue", "path": [], "history": [], "stuck_steps": 0},
    {"pos": [0, 9], "goal": [9, 9], "color": "red", "path": [], "history": [], "stuck_steps": 0},
    {"pos": [9, 0], "goal": [0, 9], "color": "green", "path": [], "history": [], "stuck_steps": 0},
    {"pos": [9, 9], "goal": [0, 0], "color": "purple", "path": [], "history": [], "stuck_steps": 0},
]

# BFS pathfinding function
def bfs(start, goal, obstacles):
    queue = deque([(start, [start])])
    visited = set([start])
    while queue:
        current, path = queue.popleft()
        if current == goal:
            return path
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            x, y = current[0] + dx, current[1] + dy
            if 0 <= x < grid_size[0] and 0 <= y < grid_size[1]:
                next_pos = (x, y)
                if next_pos not in visited and next_pos not in obstacles:
                    visited.add(next_pos)
                    queue.append((next_pos, path + [next_pos]))
    return None

# Generate random static obstacles with a check to ensure paths exist
num_static_obstacles = 15  # Increased to 15
static_obstacles = set()
robot_positions = set(tuple(robot["pos"]) for robot in robots) | set(tuple(robot["goal"]) for robot in robots)

while len(static_obstacles) < num_static_obstacles:
    obs = (random.randint(0, 9), random.randint(0, 9))
    if obs not in robot_positions:
        static_obstacles.add(obs)
        static_obstacles_set = set(static_obstacles)
        # Check if paths exist for all robots with the current set of obstacles
        all_paths_exist = True
        for robot in robots:
            start = tuple(robot["pos"])
            goal = tuple(robot["goal"])
            path = bfs(start, goal, static_obstacles_set)
            if not path:
                all_paths_exist = False
                static_obstacles.remove(obs)  # Remove the obstacle if it blocks a path
                break
        if not all_paths_exist:
            continue

static_obstacles = list(static_obstacles)
static_obstacles_set = set(static_obstacles)
print(f"Static obstacles placed: {static_obstacles}")

# Class for dynamic obstacles
class DynamicObstacle:
    def _init_(self, pos, grid_size):
        self.pos = list(pos)
        self.grid_size = grid_size

    def move(self, obstacles, robot_positions):
        # Possible movements: up, down, left, right
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        random.shuffle(directions)
        for dx, dy in directions:
            new_x, new_y = self.pos[0] + dx, self.pos[1] + dy
            new_pos = (new_x, new_y)
            # Check if the new position is within bounds and not occupied
            if (0 <= new_x < self.grid_size[0] and 0 <= new_y < self.grid_size[1] and
                new_pos not in obstacles and new_pos not in robot_positions):
                self.pos = [new_x, new_y]
                return
        # If no valid move, stay in place
        pass

# Generate initial dynamic obstacles
num_dynamic_obstacles = 8  # Increased to 8
dynamic_obstacles = []
obstacles_set = static_obstacles_set.union(set(tuple(robot["pos"]) for robot in robots))
while len(dynamic_obstacles) < num_dynamic_obstacles:
    obs = (random.randint(0, 9), random.randint(0, 9))
    if obs not in obstacles_set:
        dynamic_obstacles.append(DynamicObstacle(obs, grid_size))
        obstacles_set.add(obs)

# Compute initial paths for each robot
for robot in robots:
    start = tuple(robot["pos"])
    goal = tuple(robot["goal"])
    path = bfs(start, goal, static_obstacles_set)
    if path:
        robot["path"] = path[1:]
        print(f"Path found for {robot['color']} robot: {robot['path']}")
    else:
        print(f"No path found for {robot['color']} robot")
        robot["path"] = []

# Visualization setup for grid
def plot_grid(robots, static_obstacles, dynamic_obstacles):
    plt.imshow(grid, cmap='Greys', origin='lower')
    for robot in robots:
        plt.scatter(robot["pos"][1], robot["pos"][0], c=robot["color"], s=100, label=f'Robot {robot["color"]}')
        plt.scatter(robot["goal"][1], robot["goal"][0], c=robot["color"], marker='x', s=100)
    for obs in static_obstacles:
        plt.scatter(obs[1], obs[0], c='black', marker='s', s=100)
    for obs in dynamic_obstacles:
        plt.scatter(obs.pos[1], obs.pos[0], c='yellow', marker='s', s=100)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.pause(0.1)
    plt.clf()

# Simulation loop with obstacle avoidance and dynamic path replanning
plt.ion()
all_reached = False
max_steps = 600
step = 0
time_steps = []

while not all_reached and step < max_steps:
    current_positions = [tuple(robot["pos"]) for robot in robots]
    desired_next_positions = []

    # Move dynamic obstacles each step
    dynamic_obstacle_positions = set(tuple(obs.pos) for obs in dynamic_obstacles)
    for obs in dynamic_obstacles:
        obs.move(static_obstacles_set, set(current_positions))
    new_dynamic_obstacle_positions = set(tuple(obs.pos) for obs in dynamic_obstacles)

    # Determine desired next positions and record history
    for i, robot in enumerate(robots):
        robot["history"].append(robot["pos"].copy())  # Record current position

        # If the robot has no path or the next position is blocked, recompute the path
        if not robot["path"] or (robot["path"] and (robot["path"][0] in static_obstacles_set or robot["path"][0] in dynamic_obstacle_positions)):
            print(f"Step {step}: Robot {robot['color']} path blocked or empty. Recomputing path...")
            start = tuple(robot["pos"])
            goal = tuple(robot["goal"])
            other_positions = set(current_positions[:i] + current_positions[i+1:])
            path = bfs(start, goal, static_obstacles_set.union(dynamic_obstacle_positions).union(other_positions))
            if path:
                robot["path"] = path[1:]
                print(f"New path for {robot['color']} robot: {robot['path']}")
            else:
                print(f"No new path found for {robot['color']} robot")
                robot["path"] = []

        # Determine the desired next position
        if robot["path"]:
            desired_pos = robot["path"][0]
        else:
            desired_pos = tuple(robot["pos"])
        desired_next_positions.append(desired_pos)

    # Check for validity of each move
    valid = [True] * len(robots)
    for i in range(len(robots)):
        # Check for static and dynamic obstacles
        if desired_next_positions[i] in static_obstacles_set or desired_next_positions[i] in new_dynamic_obstacle_positions:
            valid[i] = False
            print(f"Step {step}: Robot {robots[i]['color']} blocked by obstacle at {desired_next_positions[i]}")
            # Immediately recompute path if blocked
            start = tuple(robots[i]["pos"])
            goal = tuple(robots[i]["goal"])
            other_positions = set(current_positions[:i] + current_positions[i+1:])
            path = bfs(start, goal, static_obstacles_set.union(new_dynamic_obstacle_positions).union(other_positions))
            if path:
                robots[i]["path"] = path[1:]
                print(f"Immediate new path for {robots[i]['color']} robot: {robots[i]['path']}")
            else:
                print(f"No immediate new path found for {robots[i]['color']} robot")
                robots[i]["path"] = []
        # Check for robot-robot collisions
        for j in range(len(robots)):
            if i == j:
                continue
            if desired_next_positions[i] == current_positions[j]:
                valid[i] = False
                print(f"Step {step}: Robot {robots[i]['color']} blocked by Robot {robots[j]['color']} at {desired_next_positions[i]}")
                # Immediately recompute path if blocked by another robot
                start = tuple(robots[i]["pos"])
                goal = tuple(robots[i]["goal"])
                other_positions = set(current_positions[:i] + current_positions[i+1:])
                path = bfs(start, goal, static_obstacles_set.union(new_dynamic_obstacle_positions).union(other_positions))
                if path:
                    robots[i]["path"] = path[1:]
                    print(f"Immediate new path for {robots[i]['color']} robot: {robots[i]['path']}")
                else:
                    print(f"No immediate new path found for {robots[i]['color']} robot")
                    robots[i]["path"] = []
                break

    # Update positions and paths
    all_reached = True
    for i in range(len(robots)):
        if valid[i] and desired_next_positions[i] != current_positions[i]:
            robots[i]["pos"] = list(desired_next_positions[i])
            if robots[i]["path"] and tuple(robots[i]["path"][0]) == tuple(robots[i]["pos"]):
                robots[i]["path"].pop(0)
            robots[i]["stuck_steps"] = 0  # Reset stuck counter
        else:
            robots[i]["stuck_steps"] += 1  # Increment stuck counter

        # Recompute path if stuck for too long
        if robots[i]["stuck_steps"] > 5:
            print(f"Step {step}: Robot {robots[i]['color']} is stuck for {robots[i]['stuck_steps']} steps. Recomputing path...")
            start = tuple(robots[i]["pos"])
            goal = tuple(robots[i]["goal"])
            other_positions = set(current_positions[:i] + current_positions[i+1:])
            path = bfs(start, goal, static_obstacles_set.union(new_dynamic_obstacle_positions).union(other_positions))
            if path:
                robots[i]["path"] = path[1:]
                print(f"New path for {robots[i]['color']} robot: {robots[i]['path']}")
            else:
                print(f"No new path found for {robots[i]['color']} robot")
                robots[i]["path"] = []
            robots[i]["stuck_steps"] = 0  # Reset stuck counter

        if tuple(robots[i]["pos"]) != tuple(robots[i]["goal"]):
            all_reached = False

    print(f"Step {step}: Valid moves = {valid}, Positions = {[robot['pos'] for robot in robots]}")
    plot_grid(robots, static_obstacles, dynamic_obstacles)
    time.sleep(0.5)  # Slow simulation
    time_steps.append(step)
    step += 1

# Final position recording
for robot in robots:
    robot["history"].append(robot["pos"].copy())

# Plot position vs time graphs for all robots
plt.ioff()
fig, axs = plt.subplots(2, 2, figsize=(15, 10))  # Create a 2x2 grid of subplots
axs = axs.flatten()  # Flatten the 2D array of axes for easier iteration

for i, robot in enumerate(robots):
    positions = np.array(robot["history"])  # Convert history to numpy array
    time_steps = np.arange(len(positions))  # Time steps

    # Plot X and Y positions (pos[0] is X, pos[1] is Y)
    axs[i].plot(time_steps, positions[:, 1], color='blue', label='X Position')  # Y-coordinate (horizontal position)
    axs[i].plot(time_steps, positions[:, 0], color='green', label='Y Position')  # X-coordinate (vertical position)

    # Mark start and end points
    if len(positions) > 0:
        axs[i].scatter(0, positions[0, 1], color='green', s=100, marker='o', label='Start')  # Start X
        axs[i].scatter(0, positions[0, 0], color='green', s=100, marker='o')  # Start Y
        axs[i].scatter(len(positions) - 1, positions[-1, 1], color='purple', s=100, marker='s', label='End')  # End X
        axs[i].scatter(len(positions) - 1, positions[-1, 0], color='purple', s=100, marker='s')  # End Y

    # Set labels and title for each subplot
    axs[i].set_xlabel('Time')
    axs[i].set_ylabel('Position')
    axs[i].set_title(f'Robot {i} ({robot["color"]}) Position vs Time')
    axs[i].legend()
    axs[i].grid(True)

plt.tight_layout()
plt.show()

# Plot 2D paths of all robots on the grid
plt.figure(figsize=(10, 10))
plt.imshow(grid, cmap='Greys', origin='lower')  # Plot the grid

# Plot static obstacles
for obs in static_obstacles:
    plt.scatter(obs[1], obs[0], c='black', marker='s', s=100, label='Static Obstacle' if obs == static_obstacles[0] else "")

# Plot paths, start, and end positions for each robot
for robot in robots:
    positions = np.array(robot["history"])  # Convert history to numpy array
    # Plot the path (pos[0] is X/row, pos[1] is Y/column)
    plt.plot(positions[:, 1], positions[:, 0], c=robot["color"], label=f'Robot {robot["color"]} Path')
    # Plot start position
    plt.scatter(positions[0, 1], positions[0, 0], c=robot["color"], s=150, marker='o', label=f'Robot {robot["color"]} Start')
    # Plot end position
    plt.scatter(positions[-1, 1], positions[-1, 0], c=robot["color"], s=150, marker='s', label=f'Robot {robot["color"]} End')
    # Plot goal position
    plt.scatter(robot["goal"][1], robot["goal"][0], c=robot["color"], marker='x', s=150, label=f'Robot {robot["color"]} Goal')

plt.xlabel('Y (Column)')
plt.ylabel('X (Row)')
plt.title('2D Paths of All Robots')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()