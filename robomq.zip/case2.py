import matplotlib.pyplot as plt
import numpy as np
import heapq
import random
import matplotlib.animation as animation
from matplotlib.patches import Circle

# Grid size and configuration
grid_size = (20, 20)
bg_color = "#f0f0f0"

# Fixed and Dynamic Obstacles
fixed_obstacles = {(7, 7), (12, 12), (15, 15), (3, 18), (10, 10)}  # 5 fixed obstacles
dynamic_obstacles = {(9, 7), (12, 9), (15, 11), (4, 14), (8, 16)}  # 5 dynamic obstacles

# Robot positions and goals
robot1_start = (1, 1)  # Explorer 1 (Blue)
robot1_goal = (18, 18)
robot2_start = (18, 1)  # Clearer 1 (Red)
robot3_start = (10, 1)  # Clearer 2 (Green)
robot4_start = (1, 18)  # Explorer 2 (Magenta)
robot4_goal = (18, 1)

robot1_pos = robot1_start
robot2_pos = robot2_start
robot3_pos = robot3_start
robot4_pos = robot4_start
robot2_goal = None
robot3_goal = None

# Robot capabilities
detection_radius = 4
robot2_active = True
robot3_active = True

# Path history (for trails)
robot1_path_history = [robot1_start]
robot2_path_history = [robot2_start]
robot3_path_history = [robot3_start]
robot4_path_history = [robot4_start]
max_path_history = 5  # Increased trail length

# Track stuck robots
robot2_stuck_counter = 0
robot3_stuck_counter = 0
robot2_last_pos = robot2_pos
robot3_last_pos = robot3_pos
stuck_threshold = 5  # Frames to consider a robot stuck

# Task stats
tasks_allocated = 0
obstacles_cleared = 0

# Exploration tracking
exploration_grid = np.zeros(grid_size)
exploration_grid[robot1_start] = 1
exploration_grid[robot4_start] = 1

# Exploration points for full coverage
exploration_points = [(x, y) for x in range(grid_size[0]) for y in range(grid_size[1])]
random.shuffle(exploration_points)
exploration_points1 = exploration_points[:len(exploration_points) // 2]  # Half for Robot 1
exploration_points4 = exploration_points[len(exploration_points) // 2:]  # Half for Robot 4

current_exploration_target1 = None
current_exploration_target4 = None

# Mission phase (0: Exploration, 1: Obstacle Clearing, 2: Goal Navigation)
mission_phase = 0


# Dynamic Obstacle Class
class DynamicObstacle:
    def _init_(self, pos):
        self.pos = list(pos)

    def move(self, obstacles, robot_positions):
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (1, -1), (-1, 1)]
        random.shuffle(directions)
        steps = 1  # Slower movement
        for _ in range(steps):
            for dx, dy in directions:
                new_x, new_y = self.pos[0] + dx, self.pos[1] + dy
                new_pos = (new_x, new_y)
                if (0 <= new_x < grid_size[0] and 0 <= new_y < grid_size[1] and
                        new_pos not in obstacles and new_pos not in robot_positions):
                    self.pos = [new_x, new_y]
                    return
            break


dynamic_obstacle_objects = [DynamicObstacle(obs) for obs in dynamic_obstacles]


# Move dynamic obstacles
def move_obstacles():
    robot_pos_set = {(robot1_pos[0], robot1_pos[1]), (robot2_pos[0], robot2_pos[1]),
                     (robot3_pos[0], robot3_pos[1]), (robot4_pos[0], robot4_pos[1])}
    for obs in dynamic_obstacle_objects:
        obs.move(fixed_obstacles, robot_pos_set)
    return {(obs.pos[0], obs.pos[1]) for obs in dynamic_obstacle_objects}


# A* Path Planning
def astar(start, goal, obstacles):
    def heuristic(a, b):
        return np.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)

    open_list = []
    heapq.heappush(open_list, (0, start))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}

    directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (1, -1), (-1, 1)]

    while open_list:
        _, current = heapq.heappop(open_list)
        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            return path[::-1]

        for dx, dy in directions:
            neighbor = (current[0] + dx, current[1] + dy)
            if 0 <= neighbor[0] < grid_size[0] and 0 <= neighbor[1] < grid_size[1] and neighbor not in obstacles:
                move_cost = 1.414 if abs(dx) + abs(dy) == 2 else 1
                tentative_g = g_score[current] + move_cost
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + heuristic(neighbor, goal)
                    heapq.heappush(open_list, (f_score[neighbor], neighbor))
    return []  # Return empty path if no path found


# Move robot along path with collision avoidance and stuck detection
def move_robot(robot_pos, path, other_robots, all_obstacles):
    if path:
        next_pos = path[0]
        if next_pos not in other_robots:
            return next_pos
        else:
            # Try to find an alternative path
            new_path = astar(robot_pos, path[-1], all_obstacles.union(other_robots))
            if new_path:
                return new_path[0]
            # If no path, move to a nearby free position
            directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
            random.shuffle(directions)
            for dx, dy in directions:
                new_pos = (robot_pos[0] + dx, robot_pos[1] + dy)
                if (0 <= new_pos[0] < grid_size[0] and 0 <= new_pos[1] < grid_size[1] and
                        new_pos not in all_obstacles and new_pos not in other_robots):
                    return new_pos
    return robot_pos


# Find nearest available robot for obstacle clearing
def find_nearest_robot(obstacle):
    global robot2_goal, robot3_goal, tasks_allocated
    dist2 = np.linalg.norm(np.array(robot2_pos) - np.array(obstacle)) if robot2_active and not robot2_goal else float(
        'inf')
    dist3 = np.linalg.norm(np.array(robot3_pos) - np.array(obstacle)) if robot3_active and not robot3_goal else float(
        'inf')
    if dist2 < dist3:
        robot2_goal = obstacle
        tasks_allocated += 1
        return robot2_pos
    elif dist3 < float('inf'):
        robot3_goal = obstacle
        tasks_allocated += 1
        return robot3_pos
    return None


# Get next exploration target for full coverage
def get_next_exploration_target(robot_pos, robot_id, exploration_points_list):
    global mission_phase
    all_obstacles = fixed_obstacles.union({(obs.pos[0], obs.pos[1]) for obs in dynamic_obstacle_objects})

    # If obstacles remain, target them or explore further
    if all_obstacles:
        # Try to target a nearby obstacle first
        for obs in sorted(all_obstacles, key=lambda x: np.linalg.norm(np.array(robot_pos) - np.array(x))):
            path = astar(robot_pos, obs, all_obstacles)
            if path:
                return obs

        # If no path to obstacles, explore remaining points or random points
        valid_targets = [pt for pt in exploration_points_list if pt not in all_obstacles]
        if valid_targets:
            for target in sorted(valid_targets, key=lambda x: np.linalg.norm(np.array(robot_pos) - np.array(x))):
                path = astar(robot_pos, target, all_obstacles)
                if path:
                    exploration_points_list.remove(target)
                    return target

        # If exploration list is empty but obstacles remain, reset to random points
        if not valid_targets:
            exploration_points_list.clear()
            exploration_points_list.extend([(x, y) for x in range(grid_size[0]) for y in range(grid_size[1])
                                            if (x, y) not in all_obstacles])
            random.shuffle(exploration_points_list)
            for target in exploration_points_list:
                path = astar(robot_pos, target, all_obstacles)
                if path:
                    exploration_points_list.remove(target)
                    return target

        # Fallback: move to a random reachable position
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        random.shuffle(directions)
        for dx, dy in directions:
            new_pos = (robot_pos[0] + dx, robot_pos[1] + dy)
            if (0 <= new_pos[0] < grid_size[0] and 0 <= new_pos[1] < grid_size[1] and
                    new_pos not in all_obstacles):
                return new_pos
        return robot_pos  # Stay put if no valid move
    else:
        # No obstacles left, proceed to next phase
        exploration_coverage = np.sum(exploration_grid) / (grid_size[0] * grid_size[1]) * 100
        if exploration_coverage >= 100 and mission_phase == 0:
            mission_phase = 1
        return robot_pos


# Visualization setup
fig, ax1 = plt.subplots(figsize=(10, 8))
fig.set_facecolor(bg_color)
ax1.set_facecolor(bg_color)
ax1.grid(True, linestyle='--', alpha=0.5)
ax1.set_xlim(-0.5, grid_size[0] - 0.5)
ax1.set_ylim(-0.5, grid_size[1] - 0.5)
ax1.set_title("Multi-Robot Exploration", fontsize=14, fontweight='bold')
ax1.set_xlabel("X", fontsize=10)
ax1.set_ylabel("Y", fontsize=10)

# Robot markers
robot1_marker, = ax1.plot([], [], 'bo', markersize=10, label="Explorer 1")
robot2_marker, = ax1.plot([], [], 'ro', markersize=10, label="Clearer 1")
robot3_marker, = ax1.plot([], [], 'go', markersize=10, label="Clearer 2")
robot4_marker, = ax1.plot([], [], 'mo', markersize=10, label="Explorer 2")

# Trails for all robots
robot1_trail, = ax1.plot([], [], 'b-', alpha=0.4, linewidth=1.5)
robot2_trail, = ax1.plot([], [], 'r:', alpha=0.4, linewidth=1.5)
robot3_trail, = ax1.plot([], [], 'g:', alpha=0.4, linewidth=1.5)
robot4_trail, = ax1.plot([], [], 'm-', alpha=0.4, linewidth=1.5)

# Target markers
target_marker1 = ax1.scatter([], [], c='orange', s=80, marker='x', label="Target (Exp 1)")
target_marker4 = ax1.scatter([], [], c='yellow', s=80, marker='x', label="Target (Exp 2)")

# Obstacle markers
fixed_obstacle_markers = ax1.scatter([], [], c='black', s=60, marker='s', label="Fixed Obstacle")
dynamic_obstacle_markers = ax1.scatter([], [], c='purple', s=50, marker='D', label="Dynamic Obstacle")

# Goal and start markers
goal_marker1 = ax1.scatter([robot1_goal[0]], [robot1_goal[1]], c='gold', s=100, marker='*', label="Goal (Exp 1)")
goal_marker4 = ax1.scatter([robot4_goal[0]], [robot4_goal[1]], c='pink', s=100, marker='*', label="Goal (Exp 2)")
start_marker1 = ax1.scatter([robot1_start[0]], [robot1_start[1]], c='cyan', s=80, marker='o', label="Start (Exp 1)")
start_marker4 = ax1.scatter([robot4_start[0]], [robot4_start[1]], c='lightgreen', s=80, marker='o',
                            label="Start (Exp 2)")

# Detection radius
detection_circle1 = Circle((0, 0), detection_radius, fill=False, color='blue', linestyle='--', alpha=0.3)
detection_circle4 = Circle((0, 0), detection_radius, fill=False, color='magenta', linestyle='--', alpha=0.3)
ax1.add_patch(detection_circle1)
ax1.add_patch(detection_circle4)

# Status display
status_text = ax1.text(0.5, -0.5, "", fontsize=9, bbox=dict(facecolor='white', alpha=0.8))
phase_text = ax1.text(grid_size[0] - 5, -0.5, "", fontsize=9, bbox=dict(facecolor='white', alpha=0.8))
ax1.legend(loc='upper left', bbox_to_anchor=(1.01, 1), fontsize=8, borderaxespad=0)

# Data for robot positions over time
time_data = []
robot1_x_data = []
robot2_x_data = []
robot3_x_data = []
robot4_x_data = []


# Update function
def update(frame):
    global robot1_pos, robot2_pos, robot3_pos, robot4_pos, robot2_goal, robot3_goal
    global robot1_path_history, robot2_path_history, robot3_path_history, robot4_path_history
    global tasks_allocated, obstacles_cleared, current_exploration_target1, current_exploration_target4
    global exploration_grid, mission_phase
    global time_data, robot1_x_data, robot2_x_data, robot3_x_data, robot4_x_data
    global robot2_stuck_counter, robot3_stuck_counter, robot2_last_pos, robot3_last_pos

    # Move dynamic obstacles
    dynamic_obstacles_set = move_obstacles()
    all_obstacles = fixed_obstacles.union(dynamic_obstacles_set)

    # Update exploration grid
    for robot_pos in [robot1_pos, robot4_pos]:
        x, y = robot_pos
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                nx, ny = x + dx, y + dy
                if 0 <= nx < grid_size[0] and 0 <= ny < grid_size[1]:
                    exploration_grid[nx, ny] = 1

    exploration_coverage = np.sum(exploration_grid) / (grid_size[0] * grid_size[1]) * 100

    # Determine targets for explorers
    if current_exploration_target1 is None or robot1_pos == current_exploration_target1:
        current_exploration_target1 = get_next_exploration_target(robot1_pos, 1, exploration_points1)
    if current_exploration_target4 is None or robot4_pos == current_exploration_target4:
        current_exploration_target4 = get_next_exploration_target(robot4_pos, 4, exploration_points4)

    # Plan paths for explorers
    robot1_path = astar(robot1_pos, current_exploration_target1, all_obstacles)
    robot4_path = astar(robot4_pos, current_exploration_target4, all_obstacles)

    # Detect obstacles
    detected_obstacles = []
    for robot_pos in [robot1_pos, robot4_pos]:
        for obs in all_obstacles:
            if np.linalg.norm(np.array(robot_pos) - np.array(obs)) <= detection_radius:
                detected_obstacles.append(obs)
                if (robot2_active and not robot2_goal) or (robot3_active and not robot3_goal):
                    find_nearest_robot(obs)

    # Check if clearer robots are stuck
    if robot2_pos == robot2_last_pos:
        robot2_stuck_counter += 1
    else:
        robot2_stuck_counter = 0
    if robot3_pos == robot3_last_pos:
        robot3_stuck_counter += 1
    else:
        robot3_stuck_counter = 0

    # If stuck, reassign goal or move to a free position
    if robot2_stuck_counter >= stuck_threshold and robot2_goal:
        robot2_goal = None  # Clear goal to reassign
        robot2_stuck_counter = 0
    if robot3_stuck_counter >= stuck_threshold and robot3_goal:
        robot3_goal = None  # Clear goal to reassign
        robot3_stuck_counter = 0

    # Update clearer robots
    if robot2_goal:
        robot2_path = astar(robot2_pos, robot2_goal, all_obstacles - {robot2_goal})
        robot2_last_pos = robot2_pos
        robot2_pos = move_robot(robot2_pos, robot2_path, {robot1_pos, robot3_pos, robot4_pos}, all_obstacles)
        robot2_path_history.append(robot2_pos)
        if len(robot2_path_history) > max_path_history:
            robot2_path_history.pop(0)
        if robot2_pos == robot2_goal:
            dynamic_obstacles_set.discard(robot2_goal)
            fixed_obstacles.discard(robot2_goal)
            for obs in dynamic_obstacle_objects:
                if (obs.pos[0], obs.pos[1]) == robot2_goal:
                    dynamic_obstacle_objects.remove(obs)
                    break
            robot2_goal = None
            obstacles_cleared += 1

    if robot3_goal:
        robot3_path = astar(robot3_pos, robot3_goal, all_obstacles - {robot3_goal})
        robot3_last_pos = robot3_pos
        robot3_pos = move_robot(robot3_pos, robot3_path, {robot1_pos, robot2_pos, robot4_pos}, all_obstacles)
        robot3_path_history.append(robot3_pos)
        if len(robot3_path_history) > max_path_history:
            robot3_path_history.pop(0)
        if robot3_pos == robot3_goal:
            dynamic_obstacles_set.discard(robot3_goal)
            fixed_obstacles.discard(robot3_goal)
            for obs in dynamic_obstacle_objects:
                if (obs.pos[0], obs.pos[1]) == robot3_goal:
                    dynamic_obstacle_objects.remove(obs)
                    break
            robot3_goal = None
            obstacles_cleared += 1

    # Move explorers
    robot1_pos = move_robot(robot1_pos, robot1_path, {robot2_pos, robot3_pos, robot4_pos}, all_obstacles)
    robot4_pos = move_robot(robot4_pos, robot4_path, {robot1_pos, robot2_pos, robot3_pos}, all_obstacles)
    robot1_path_history.append(robot1_pos)
    robot4_path_history.append(robot4_pos)
    if len(robot1_path_history) > max_path_history:
        robot1_path_history.pop(0)
    if len(robot4_path_history) > max_path_history:
        robot4_path_history.pop(0)

    # Update mission phase for clearing
    if mission_phase == 1:
        if not all_obstacles:  # Only move to goal navigation when all obstacles are cleared
            mission_phase = 2
            current_exploration_target1 = robot1_goal
            current_exploration_target4 = robot4_goal

    # Update visualization
    robot1_marker.set_data([robot1_pos[0]], [robot1_pos[1]])
    robot2_marker.set_data([robot2_pos[0]], [robot2_pos[1]])
    robot3_marker.set_data([robot3_pos[0]], [robot3_pos[1]])
    robot4_marker.set_data([robot4_pos[0]], [robot4_pos[1]])

    if current_exploration_target1:
        target_marker1.set_offsets(
            np.array([current_exploration_target1[0], current_exploration_target1[1]]).reshape(1, 2))
    if current_exploration_target4:
        target_marker4.set_offsets(
            np.array([current_exploration_target4[0], current_exploration_target4[1]]).reshape(1, 2))

    # Update trails for all robots
    if robot1_path_history:
        x1, y1 = zip(*robot1_path_history)
        robot1_trail.set_data(x1, y1)
    if robot2_path_history:
        x2, y2 = zip(*robot2_path_history)
        robot2_trail.set_data(x2, y2)
    if robot3_path_history:
        x3, y3 = zip(*robot3_path_history)
        robot3_trail.set_data(x3, y3)
    if robot4_path_history:
        x4, y4 = zip(*robot4_path_history)
        robot4_trail.set_data(x4, y4)

    detection_circle1.center = robot1_pos
    detection_circle4.center = robot4_pos

    fixed_x, fixed_y = zip(*fixed_obstacles) if fixed_obstacles else ([], [])
    fixed_obstacle_markers.set_offsets(np.c_[fixed_x, fixed_y])
    dynamic_x, dynamic_y = zip(*dynamic_obstacles_set) if dynamic_obstacles_set else ([], [])
    dynamic_obstacle_markers.set_offsets(np.c_[dynamic_x, dynamic_y])

    remaining_obstacles = len(fixed_obstacles) + len(dynamic_obstacles_set)
    status_text.set_text(f"Tasks: {tasks_allocated} | Cleared: {obstacles_cleared} | "
                         f"Left: {remaining_obstacles} | Explored: {exploration_coverage:.1f}%")
    phase_names = ["Exploring", "Clearing", "Navigating"]
    phase_text.set_text(f"Phase: {phase_names[mission_phase]}")

    # Update graph data
    time_data.append(frame)
    robot1_x_data.append(robot1_pos[0])
    robot2_x_data.append(robot2_pos[0])
    robot3_x_data.append(robot3_pos[0])
    robot4_x_data.append(robot4_pos[0])

    # Stop animation when all robots reach their goals and all obstacles are cleared
    if (robot1_pos == robot1_goal and robot4_pos == robot4_goal and
            robot2_goal is None and robot3_goal is None and not all_obstacles):
        ani.event_source.stop()
        plt.close(fig)
        fig2, axs = plt.subplots(2, 2, figsize=(12, 8))
        fig2.suptitle("Robot Positions Over Time", fontsize=16)
        axs[0, 0].plot(time_data, robot1_x_data, 'b-', label="Explorer 1")
        axs[0, 0].set_title("Explorer 1")
        axs[0, 0].set_xlabel("Time (Frames)")
        axs[0, 0].set_ylabel("X Position")
        axs[0, 0].grid(True, linestyle='--', alpha=0.5)
        axs[0, 0].legend()

        axs[0, 1].plot(time_data, robot2_x_data, 'r:', label="Clearer 1")
        axs[0, 1].set_title("Clearer 1")
        axs[0, 1].set_xlabel("Time (Frames)")
        axs[0, 1].set_ylabel("X Position")
        axs[0, 1].grid(True, linestyle='--', alpha=0.5)
        axs[0, 1].legend()

        axs[1, 0].plot(time_data, robot3_x_data, 'g:', label="Clearer 2")
        axs[1, 0].set_title("Clearer 2")
        axs[1, 0].set_xlabel("Time (Frames)")
        axs[1, 0].set_ylabel("X Position")
        axs[1, 0].grid(True, linestyle='--', alpha=0.5)
        axs[1, 0].legend()

        axs[1, 1].plot(time_data, robot4_x_data, 'm-', label="Explorer 2")
        axs[1, 1].set_title("Explorer 2")
        axs[1, 1].set_xlabel("Time (Frames)")
        axs[1, 1].set_ylabel("X Position")
        axs[1, 1].grid(True, linestyle='--', alpha=0.5)
        axs[1, 1].legend()

        plt.tight_layout()
        plt.show()

    return (robot1_marker, robot2_marker, robot3_marker, robot4_marker,
            robot1_trail, robot2_trail, robot3_trail, robot4_trail,
            fixed_obstacle_markers, dynamic_obstacle_markers,
            detection_circle1, detection_circle4, status_text, target_marker1, target_marker4, phase_text)


# Animation with slower speed
ani = animation.FuncAnimation(fig, update, interval=300, blit=True)  # Slower speed (300 ms)
plt.tight_layout(pad=3.0)
plt.show()